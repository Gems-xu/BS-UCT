import shutil

i = 4
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 11
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 27
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 35
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 45
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 58
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 63
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')