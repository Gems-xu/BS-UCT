import shutil

i = 7
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 11
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 19
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 29
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 41
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

i = 45
shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')

# i = 63
# shutil.copyfile('input' + str(1) + '.npy', 'input' + str(i) + '.npy')
# shutil.copyfile('output' + str(1) + '.npy', 'output' + str(i) + '.npy')
# shutil.copyfile('record' + str(1) + '.npy', 'record' + str(i) + '.npy')
# shutil.copyfile('result' + str(1) + '.npy', 'result' + str(i) + '.npy')